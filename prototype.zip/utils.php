<?php

function truncate($string,$length=100,$append="&hellip;") {
  $string = trim($string);

  if(strlen($string) > $length) {
    $string = wordwrap($string, $length);
    $string = explode("\n", $string, 2);
    $string = $string[0] . $append;
  }

  return $string;
}

function format_sentiment($text) {
	$format = 'text-primary';
	if (strcasecmp("negative", $text) == 0) {
		$format = 'text-danger';
	} else if (strcasecmp("positive", $text) == 0) {
		$format = 'text-success';
	} else if (strcasecmp("neutral", $text) == 0) {
		$format = 'text-muted';
	}
	return '<span class="'.$format.'">'.$text.'</span>';
}

?>