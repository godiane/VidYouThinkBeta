<?php
	require_once __DIR__ . '/constants.php';
	
	function debugOverallSentiment($topCommentSentiment, $phraseSentiment, $captionsSentiment, $phraseAndCaptionsSentiment) {
		echo "Top Comment Sentiment: " . $topCommentSentiment . "<br/>";
		echo "Phrase Sentiment: " . $phraseSentiment . "<br/>";
		echo "Captions Sentiment: " . $captionsSentiment . "<br/>";
		echo "Phrase and Captions Sentiment: " . $phraseAndCaptionsSentiment . "<br/>";
	}
	
	function getOverallSentiment($topCommentSentiment, $phraseSentiment, $captionsSentiment) {
		$phraseAndCaptionsSentiment = "neutral";
		// echo "TEST! " . $phraseSentiment . " :: " . (preg_match("positive", $phraseSentiment));
		if (strpos($phraseSentiment, "positive") !== false) {
			if (strpos($captionsSentiment, "positive") !== false) {
				$phraseAndCaptionsSentiment = "positive";
			} else if (strpos($captionsSentiment, "negative") !== false) {
				$phraseAndCaptionsSentiment = "negative";		
			} else {
				// FIXME debugOverallSentiment($topCommentSentiment, $phraseSentiment, $captionsSentiment, $phraseAndCaptionsSentiment);
				return "Invalid";
			}
		} else if (strpos($phraseSentiment, "neutral") !== false) {
			if (strpos($captionsSentiment, "negative") !== false) {
				$phraseAndCaptionsSentiment = "negative";
			}  else {
				// FIXME debugOverallSentiment($topCommentSentiment, $phraseSentiment, $captionsSentiment, $phraseAndCaptionsSentiment);
				return "Invalid";
			}
		} else if (strpos($phraseSentiment, "negative") !== false) {
				$phraseAndCaptionsSentiment = "negative";		
		} else {
			// FIXME debugOverallSentiment($topCommentSentiment, $phraseSentiment, $captionsSentiment, $phraseAndCaptionsSentiment);
			return "Invalid";
		}
		
		if (strpos($phraseAndCaptionsSentiment, "positive") !== false) {
			if (strpos($topCommentSentiment, "positive") !== false) {
				return "positive";
			} else if (strpos($topCommentSentiment, "negative") !== false) {
				return "negative";
			} else if (strpos($topCommentSentiment, "neutral") !== false) {
				return "neutral";
			} else {
				// FIXME debugOverallSentiment($topCommentSentiment, $phraseSentiment, $captionsSentiment, $phraseAndCaptionsSentiment);
				return "Invalid";
			}
		}  else if (strpos($phraseAndCaptionsSentiment, "negative") !== false) {
			return "negative";
		}  else if (strpos($phraseAndCaptionsSentiment, "neutral") !== false) {
			if (strpos($topCommentSentiment, "negative") !== false) {
				return "negative";
			} else {
				return "neutral";
			}
		} else {
			// FIXME debugOverallSentiment($topCommentSentiment, $phraseSentiment, $captionsSentiment, $phraseAndCaptionsSentiment);
			return "Invalid";
		}	
	}
	
	function getSentimentAnalysisJSON($text, $videoId = NULL, $type = NULL, $saveToFile = false) {
		if (!empty(videoId)) {
			$file = 'json/' . $videoId . '.' . $type . '.sentiment.json';
		}
		if (!file_exists($file)) {
			$uri = HP_HAVEN_URI_1 . urlencode($text) . HP_HAVEN_URI_2;
			$response = \Httpful\Request::get($uri)->expectsJson()->send();
			if ($saveToFile) {
				file_put_contents($file, json_encode($response->body, JSON_PRETTY_PRINT));			
			}
			return $response->body->sentiment_analysis[0]->aggregate->sentiment;
		} else {
			$arr = json_decode(file_get_contents($file), true);
			return $arr['sentiment_analysis'][0]['aggregate']['sentiment'];
		}
	}

?>